/**
 * @license Copyright (c) 2011-2012 Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/rhc/pro/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
(function() {
    // register namespace
    $.extend(true, window, {
        "Insight" : {
            "InformationPanel" : InformationPanel
        }
    });
    var componentTemplate, infoPanelErrorTemplate, securityEditorTemplate, licenseEditorTemplate;

	$(document).ready(function() {
		securityEditorTemplate = Hogan.compile($('#infoPanelSecurityEditor').html());
		licenseEditorTemplate = Hogan.compile($('#infoPanelLicenseEditor').html());
		componentTemplate = Hogan.compile($('#infoPanelComponentTemplate').html());
		infoPanelErrorTemplate = Hogan.compile($('#infoPanelErrorTemplate').html());
	});

	function isNullOrUndefined(obj) {
		return obj === null || typeof obj === 'undefined';
	}

	function isNotNullOrUndefined(obj) {
		return !isNullOrUndefined(obj);
	}

    function InformationPanel(options) {
        var currentView = null, currentRow = null, currentFileHash = null, currentMatchState = null, currentGav = {
            groupId : null,
            artifactId : null,
            version : null
        }, _grid, _timer, currentItemId, licenseThreats, similarityTable, _defaults = {
            partialDisplay : false,
            sampleData : false,
            byHash : false
        };

        function init(grid) {
            _grid = grid;
            options = $.extend(true, {}, _defaults, options);

            //setup the click handler for switching views
            $('a[data-infoContainerId]').click(viewSwitch);
            if (Insight.isReadOnly()) {
                $('a[data-infoContainerId=informationPanelEditSV]','#informationPanel').hide();
                $('a[data-infoContainerId=informationPanelEditLicense]', '#informationPanel').hide();
            }
            //setup the click handler to close the panel
            $('.close', '#informationPanel').click(hide);
            _grid.onClick.subscribe(gridClickedFn);

            //setup data handler to close panel on page/sort/filter
            _grid.getData().onRowCountChanged.subscribe(rowCountChangedFn);
            _grid.getData().onRowsChanged.subscribe(rowChangedFn);
        }

        function destroy() {
            //dump all the content
            hide();

            //clean up the listeners
            _grid.getData().onRowsChanged.unsubscribe(rowChangedFn);
            _grid.getData().onRowCountChanged.unsubscribe(rowCountChangedFn);
            _grid.onClick.unsubscribe(gridClickedFn);
            $('.close', '#informationPanel').unbind('click', hide);
            $('a[data-infoContainerId]').unbind('click', viewSwitch);
        }

        function gridClickedFn(e, args) {
            //we only want to handle this when the user clicked on a part of the row that isn't 
            //used for something else i.e. checkboxes
            //also has some logic in here to not process if a double click was performed
            if (e.target.tagName !== "INPUT" && $(e.target).children('input:first').length === 0) {
                if (isNotNullOrUndefined(_timer)) {
                    clearTimeout(_timer);
                    _timer = null;
                } else {
                    _timer = setTimeout(function() {
                        _timer = null;
                        var currentItem = _grid.getDataItem(args.row);
                        currentItemId = currentItem.id;
                        args.gav = {
                            groupId : currentItem.groupId,
                            artifactId : currentItem.artifactId,
                            version : currentItem.version
                        };
                        args.filehash = currentItem.hash;

                        if (currentItem.matchState === 'unknown') {
                            if (currentItem.scanError) {
                                args.matchState = 'error';
                            } else if (currentItem.proprietary) {
                                args.matchState = 'proprietary';
                            }
                        } else if (currentItem.matchState) {
                            args.matchState = currentItem.matchState;
                            if (currentItem.proprietary) {
                                args.matchState += ' (proprietary)';
                            }
                        } else {
                            //Not necessarily a huge fan of hardcoding exact here, but the sec/lic views only show exact matches
                            args.matchState = 'exact';
                        }

                        toggle(e, args);
                    }, 250);
                }
            }
        }
        
        function rowCountChangedFn(e, args) {
            //when row count changes, because of filtering, I just don't have a solid way to know if the row previously
            //selected is still in the filtered list, so im just going to hide it
            hide();
        }

        function rowChangedFn(e, args) {
            var row = currentRow;
            
            //do in future to allow proper row to get selected
            setTimeout(function(){
                var rows = _grid.getSelectedRows();
                if (isNotNullOrUndefined(row) && rows.length == 1) {
                    //if the current record has switched rows, need to hide and show again
                    if (row != rows[0]) {
                        hide();
                        if (isNotNullOrUndefined(currentItemId)) {
                            show({row:rows[0],cell:1}, _grid.getCanvasNode());
                            buildView(currentView, _grid.getData().getItemById(currentItemId));
                        }
                    } else {
                        var infoPanel = $('#informationPanel');
                        var infopanelTop = infoPanel.offset().top;
                        var infopanelBottom = infopanelTop + infoPanel.height();
                        var viewport = $(_grid.getCanvasNode()).parent();
                        var viewportTop = viewport.offset().top;
                        var viewportBottom = viewportTop + viewport.height();
                        var cellNode = _grid.getCellNode(row, 1);
                        if ( isNullOrUndefined(cellNode) ) {
                            _grid.scrollRowIntoView(row);
                            cellNode = _grid.getCellNode(row, 1);
                        }
                        
                        //scroll the div if necessary            
                        if ( infopanelBottom > viewportBottom || infopanelTop < viewportTop ) {
                            var selectedRowTop = infoPanel.offset().top - cellNode.offsetParent.clientHeight;
                            viewport.scrollTop(viewport.scrollTop() + selectedRowTop - viewport.offset().top);
                        }
                    }
                } else {
                    hide();
                }
            },10);
        }

        function viewSwitch() {
            var infoContainerId = $(this).attr('data-infoContainerId');
            if (infoContainerId) {
                // hide
                $('[data-infoContainer]').css('display', 'none');
                // show
                $('#' + infoContainerId).css('display', '');

                buildView(infoContainerId, _grid.getData().getItemById(currentItemId));
            }
        }

        function toggle(event, args) {
            currentGav.groupId = args.gav.groupId;
            currentGav.artifactId = args.gav.artifactId;
            currentGav.version = args.gav.version;
            currentFileHash = args.filehash;
            currentMatchState = args.matchState;

            _grid.removeCellCssStyles('popout');

            if (isNullOrUndefined(currentRow) || currentRow != args.row) {
                show(_grid.getCellFromEvent(event), $(event.currentTarget));
                buildView(currentView, _grid.getData().getItemById(currentItemId));
            } else {
                hide();
            }
        }

		function getErrorFn(selector, retryFn) {
			return function () {
				var node = $(selector);
				node.html(infoPanelErrorTemplate.render());
				$('.btn', node).click(function() {
					retryFn();
				});
			};
        }

        function buildView(view, item) {
            currentView = view;

            //first time through here so load the default views data
            if (isNullOrUndefined(currentView)) {
                currentView = $('li.active > a[data-infoContainerId]', '#informationPanel').attr('data-infoContainerId') || 'informationPanelArtifact';
            }

            trackEvent('component_info_panel', currentView);

            switch (currentView) {
            case 'informationPanelArtifact':
                loadArtifactInfo();
                break;
            case 'informationPanelPartialMatch':
            	loadPartialMatchInfo();
                break;
            case 'informationPanelFileDetail':
            	if (options.sampleData) {
            		resetView(currentView);
            	} else {
            		loadFileDetailInfo();
            	}
            	break;
            case 'informationPanelEditLicense':
                if (freemium && !options.sampleData) {
                    resetView(currentView);
                } else {
                    createLicenseEditor(item, $('#informationPanelEditLicense'));
                }
                break;
            case 'informationPanelEditSV':
                if (freemium && !options.sampleData) {
                    resetView(currentView);
                } else {
                    createSVEditor(item, $('#informationPanelEditSV'));
                }
                break;
            case 'informationPanelAudit':
                if (freemium && !options.sampleData) {
                    resetView(currentView);
                } else {
                    loadAuditInfo();
                }
                break;
            case 'informationPanelLabels':
                createLabelContent(item, $('#informationPanelLabels'));
                break;
            }
        }

        function resetView(currentView) {
            //hide them all and show the default one
            $('[data-infoContainer]').css('display', 'none');
            $('#informationPanelArtifact').css('display', '');
            $('a[data-infoContainerId=informationPanelArtifact]').parent().addClass('active');
            $('a[data-infoContainerId='+currentView+']').parent().removeClass('active');
            buildView(null);
        }

        function show(cell, target) {
            var cellCss = {}, cellNode = _grid.getCellNode(cell.row, cell.cell), infoPanel = $('#informationPanel'), //
            viewport = $(_grid.getCanvasNode()).parent(), viewportBottom = viewport.offset().top + viewport.height();
            
            //just in case the row being moved too is out of the cache
            if ( isNullOrUndefined(cellNode) ) {
                _grid.scrollRowIntoView(cell.row);
                cellNode = _grid.getCellNode(cell.row, cell.cell);
            }

            //put on bottom of selected row
            infoPanel.css('top', cellNode.offsetParent.offsetTop + cellNode.offsetParent.clientHeight);
            infoPanel.addClass('shadowBottom');
            infoPanel.removeClass('shadowTop');

            if ((freemium && !options.sampleData) || _grid.getData().getItemById(currentItemId).matchState === 'unknown') {
                $('a[data-infoContainerId=informationPanelEditSV]', infoPanel).hide();
                $('a[data-infoContainerId=informationPanelEditLicense]', infoPanel).hide();
                $('a[data-infoContainerId=informationPanelAudit]', infoPanel).hide();
                $('a[data-infoContainerId=informationPanelPartialMatch]').hide();
                $('a[data-infoContainerId=informationPanelLabels]', infoPanel).hide();
                if ($('li.active > a[data-infocontainerid]', infoPanel).is(':hidden')) {
					$('li.active', infoPanel).removeClass('active');
					$('ul.nav > li:first', infoPanel).addClass('active');
					clean();
					currentView = $('li.active > a[data-infocontainerid]', infoPanel).data('infocontainerid');
					$('#' + currentView).show();
                }
            } else {
				if (!Insight.isReadOnly()) {
                    $('a[data-infoContainerId=informationPanelEditSV]').show();
                    $('a[data-infoContainerId=informationPanelEditLicense]').show();
            	}
                $('a[data-infoContainerId=informationPanelAudit]').show();
                $('a[data-infoContainerId=informationPanelPartialMatch]').text(getSimilarComponentTitle()).show();

				if (Insight.getFeatures().labels === true) {
				    $('a[data-infoContainerId=informationPanelLabels]', infoPanel).show();
				} else {
				    $('a[data-infoContainerId=informationPanelLabels]', infoPanel).hide();
				}
            }
            
            if (options.sampleData) {
                $('a[data-infoContainerId=informationPanelFileDetail]').hide();
            } else {
                $('a[data-infoContainerId=informationPanelFileDetail]').show();
            }

            //move the panel into place
            infoPanel.appendTo(target);
            infoPanel.show();
            currentRow = cell.row;
            cellCss[currentRow] = {};
            $.each(_grid.getColumns(), function(index, item) {
                cellCss[currentRow][item.id] = 'popout';
            });
            _grid.setCellCssStyles('popout', cellCss);
            
            var infopanelBottom = infoPanel.offset().top + infoPanel.height();
            var infopanelTop = infoPanel.offset().top;
            var viewportTop = viewport.offset().top;

            //scroll the div if necessary
            if ( infopanelBottom > viewportBottom || infopanelTop < viewportTop ) {
                var selectedRowTop = infopanelTop - cellNode.offsetParent.clientHeight;
                viewport.scrollTop(viewport.scrollTop() + selectedRowTop - viewportTop);
            }
            
            infoPanel.css('width', viewport.width() - (viewport.get(0).scrollHeight > viewport.height() ? _grid.getScrollbarDimensions().width : 0 ) - /*border*/2 + 'px');
        }

        function getSimilarComponentTitle() {
            return ((currentMatchState && currentMatchState.indexOf('similar') >= 0) ? '' : 'No ') + 'Similar Components';
        }

        function hide() {
            var infoPanel = $('#informationPanel');
            infoPanel.hide();
            //since we reuse the same dom, need to just push it out to body to hold
            infoPanel.appendTo($('body'));
            _grid.removeCellCssStyles('popout');
            currentRow = null;
            clean();
        }

        function clean() {
            resetArtifactInfo();
            resetPartialMatchInfo();
            resetFileDetailInfo();
            cleanLicenseEditor($('#informationPanelEditLicense'));
            cleanSVEditor($('#informationPanelEditSV'));
            $('#informationPanelLabels').empty();
            resetAuditInfo();
		}

        function resetArtifactInfo() {
			$('#informationPanelArtifact').empty();
        }

        function resetPartialMatchInfo() {
            InsightDatatable.removeSimilarityTable();
            $('#informationPanelPartialMatch').empty();
        }
        
        function resetFileDetailInfo() {
            $('#informationPanelFileDetail').empty();
        }

        function resetAuditInfo() {
            InsightDatatable.removeAuditTable();
            $('#informationPanelAudit').empty();
        }

        function loadArtifactInfo() {
			resetArtifactInfo();

			if (isNullOrUndefined(currentGav.groupId) || isNullOrUndefined(currentGav.artifactId) || isNullOrUndefined(currentGav.version)) {
				$('#informationPanelArtifact').html("<div class='infoPanelText'>Unknown Artifact</div>");
			} else {
				$.getJSON(getVersionInfoUrl(), function(data) {
					var colorCls = 'artifactInfoSecurity',
						lvl = Math.floor(data.securityThreatLevel);

					if (data.securityThreatCount <= 0) {
						lvl = 'NA';
						colorCls += ' artifactInfoSecurityUnspecified';
					} else if (lvl >= 8) {
						colorCls += ' artifactInfoSecurityCritical';
					} else if (lvl >= 4) {
						colorCls += ' artifactInfoSecuritySevere';
					} else if (lvl >= 0) {
						colorCls += ' artifactInfoSecurityModerate';
					} else {
						lvl = 'Unscored';
						colorCls += ' artifactInfoSecurityModerate';
					}

					data = $.extend(data, {
								"partial" : options.partialDisplay,
								"overriddenLicenses" : renderLicenses(data.overriddenLicenses, '-'),
								"declaredLicenses" : declaredLicenseFormat(data),
								"observedLicenses" : observedLicenseFormat(data),
								"currentMatchState" : currentMatchState,
								"colorCls" : colorCls,
								"lvl" : lvl,
								"cataloged" : HealthCheck.getAge(new Date(data.catalogDate)),
								"multipleSecurity" : data.securityThreatCount > 1 });

					$('#informationPanelArtifact').html(componentTemplate.render(data));

					Insight.ComponentInformation({ data : data, partialDisplay : options.partialDisplay });
				}).error(getErrorFn('#informationPanelArtifact', loadArtifactInfo));
            }
        }

        function loadPartialMatchInfo() {
            resetPartialMatchInfo();

            if (currentFileHash) {
                $.getJSON((options.sampleData ? 'sample-' : '') + 'partialmatched.json', function(data) {
                    //don't bother if there is no data to use
                    var found = false;
                    var matchDetails = null;

                    for ( var i = 0; i < data.aaData.length; i++) {
                        if (data.aaData[i].hash == currentFileHash) {
                            matchDetails = data.aaData[i].matchDetails;
                            break;
                        }
                    }
                    if (matchDetails) {
						$('#informationPanelPartialMatch').html("<div id='similarityTable' class='borderedTable'></div>");
						InsightDatatable.createSimilarityTable(matchDetails);
                    } else {
						$('#informationPanelPartialMatch').html("<div class='infoPanelText'>No similar matches were found for this component.</div>");
                    }
                }, getErrorFn('#informationPanelPartialMatch', loadPartialMatchInfo));
            } else {
				$('#informationPanelPartialMatch').html("<div class='infoPanelText'>No similar matches were found for this component.</div>");
            }
        }
        
        function loadFileDetailInfo() {
        	resetFileDetailInfo();
        	
        	//get what we want from the bom
        	$.getJSON('bom.json', function(data) {
        		var fileDetails = [];
        		//we are dealing with an item from the component view if byHash is true, so we will only show files associated with that single hash
                if (options.byHash) {
                	for ( var i = 0; i < data.aaData.length; i++) {
                        if (data.aaData[i].hash == currentFileHash) {
                        	fileDetails.push(data.aaData[i]);
                            break;
                        }
                    }
                //otherwise we are dealing with an item from the security/license view, so we want to show all files associated with any hash that matches (or similar matches) the gav
                } else {
                	for ( var i = 0; i < data.aaData.length; i++) {
                        if (data.aaData[i].groupId == currentGav.groupId && data.aaData[i].artifactId == currentGav.artifactId && data.aaData[i].version == currentGav.version) {
                        	fileDetails.push(data.aaData[i]);
                        }
                    }
                }
                
                if (fileDetails.length > 0) {
                	fileDetails.sort();
                	
                	var html = "<div class='infoPanelText fileDetail'>";
                	
                	//go through each record
                    for ( var i = 0; i < fileDetails.length; i++) {
                    	//pull out each file
                    	for ( var j = 0 ; j < fileDetails[i].pathnames.length ; j++) {
                    		var splitpath = splitPathname(fileDetails[i].pathnames[j]);
                    		html += '<b>' + splitpath[0] + '</b>';
                    		if (splitpath[1].length > 0) {
                    			html += ' <i>located at</i> ' + splitpath[1]
                    		}
                    		html += '<br><br>';
                    	}
                    }
                	
                	html += "</div>";
					$('#informationPanelFileDetail').html(html);
                } else {
                	$('#informationPanelFileDetail').html("<div class='infoPanelText'>Invalid data encountered, no files are associated with this component.</div>");
                }
            }, getErrorFn('#informationPanelFileDetail', loadFileDetailInfo));
        }
        
        function splitPathname(pathname) {
        	var idx = pathname.lastIndexOf('/');
        	
        	if ( idx == -1 ) {
        		return [pathname,''];
        	}
        	
        	var file = pathname.substring(idx + 1);
        	var path = pathname.substring(0,idx);
        	
        	return [file,path];
        }

		function createLabelContent(item, node) {
			var timestamp = (new Date()).getTime(),
				container = $('<div id="labels-' + timestamp + '"></div>'),
				retry = function() {
					if (Insight.LabelEditor) {
						Insight.LabelEditor(container, applicationId, item.hash);
					} else {
						setTimeout(retry, 1000);
					}
				};
			node.empty();
			container.appendTo(node);

			retry();
		}

        function loadAuditInfo() {
            resetAuditInfo();

            var baseAuditUrl = '../auditLog/licenses.json+security.json';
            if (demoMode) {
                baseAuditUrl = 'auditLog-' + currentGav.artifactId + '.json';
            }

            if (currentGav.artifactId) {
                $.getJSON(baseAuditUrl, 'key='+JSON.stringify(currentGav), function(data) {
                    if (data) {
                        $('#informationPanelAudit').html('<div id="auditTable" class="borderedTable"></div>');
                        InsightDatatable.createAuditTable(data.aaData);
                    } else {
                        noAuditLog();
                    }
                }).error(demoMode ? noAuditLog : getErrorFn('#informationPanelAudit', loadAuditInfo));
            } else {
                noAuditLog();
            }
        }

        function noAuditLog() {
            $('#informationPanelAudit').html("<div style='width:99%;padding:7px 0 5px 1%;vertical-align:-12px;'>No changes were found for this component.</div>");
        }

        function renderLicenses(licenses, emptyText) {
            return isNotNullOrUndefined(licenses) && licenses.length > 0 ? licenses.join(', ') : (emptyText ? emptyText : '');
        }

        function declaredLicenseFormat(data) {
            return renderLicenses(data.declaredLicenses).replace('Not Provided', 'Not Declared');
        }

        function observedLicenseFormat(data) {
            return renderLicenses(data.observedLicenses).replace('Not Provided', 'No Sources');
        }

        function getVersionInfoUrl() {
            var baseArtifactUrl = '../artifactDetails/';
            if (demoMode) {
                baseArtifactUrl = demoArtifactUrl;
            }
            return baseArtifactUrl + reportId + '?groupId=' + currentGav.groupId + '&artifactId=' + currentGav.artifactId + '&version=' + currentGav.version + (freemium ? '&freemium=true' : '');
        }

        function updateComponentTable() {
        	var id = $(_grid.getCanvasNode()).parents('[data-container=true]').attr('id');
			id = id.substring(0, id.length - 9);
			
		    if (id === 'component') {
		    	var items = _grid.getSelectedRows();
	            if (items.length == 1) {
	            	var dataView = _grid.getData();
	            	dataView.beginUpdate();
	            	var dataItem = _grid.getDataItem(items[0]);
	            	dataItem.modified = true;
	            	dataView.updateItem(dataItem.id, dataItem);
	    			dataView.endUpdate();
	            }
		    }
        }

        function createLicenseEditor(item, node) {
            cleanLicenseEditor(node);
            var timestamp = (new Date()).getTime(), container = $('<div id="licenseEditor' + timestamp + '"></div>').appendTo(node);

            toLicense(
                    item,
                    function(artifact, active) {
						var options = {
								"timestamp" : timestamp,
								"width" : 400,
								"callback" : function(errorMsg) {
									trackEvent('component_info_panel', 'update_license');
									if (isNullOrUndefined(errorMsg)) {
										updateComponentTable();
										addSuccessMessage('Updated license for ' + artifact.groupId + ':' + artifact.artifactId + ':' + artifact.version);
									} else {
										addErrorMessage(errorMsg);
									}
								}
							},
							licenseListId = "#licenseList" + options.timestamp,
							licenseEditor;

						if (active) {
							options.dataView = _grid.getData();
							options.artifacts = [ _grid.getData().getItemById(currentItemId) ];
						} else {
							options.dataView = new Slick.Data.DataView();
							artifact.id = 0;
							options.dataView.setItems([ artifact ]);
							options.artifacts = [ artifact ];
                        }
						$(container).html(licenseEditorTemplate.render({ "timestamp" : timestamp }));
						licenseEditor = new InsightDatatable.LicenseEditor(options);
						licenseEditor.show('#editor' + timestamp);

                        loadLicenseThreats(function(licenseThreats) {
                            var licenseList = '';
                            licenseList += '<li class="nav-header">Declared Licenses</li>';
                            $.each(artifact.declaredLicenses, function(index, item) {
                                licenseList += '<li>' + InsightDatatable.getLicenseThreatImg(licenseThreats[item]) + ' ' +
												(item === 'Not Provided' ? 'Not Declared' : item) + '</li>';
                            });
                            licenseList += '<li class="divider"></li><li class="nav-header">Observed Licenses</li>';
                            $.each(artifact.observedLicenses, function(index, item) {
                                licenseList += '<li>' + InsightDatatable.getLicenseThreatImg(licenseThreats[item]) + ' ' +
												(item === 'Not Provided' ? 'No Sources' : item) + '</li>';
                            });
                            $(licenseList).appendTo(licenseListId);
                        });
                    },
                    getErrorFn(node, function() {
						createLicenseEditor(item,node);
                    }));
        }

        function loadLicenseThreats(callback) {
            if (isNotNullOrUndefined(licenseThreats)) {
                callback.apply(null, [ licenseThreats ]);
                return;
            }
            $.getJSON('licensethreats.json').success(function(jsonData) {
                licenseThreats = jsonData.aaData;
                callback.apply(null, [ licenseThreats ]);
            }).error(function(resp, type, msg) {
                addErrorMessage('Loading license categorization: ' + msg);
            });
        }

        function cleanLicenseEditor(node) {
            $('a', node).unbind('click');
            $('select', node).each(function() {
                $(this).selectmenu('destroy');
            });
            $(node).empty();
        }

        function cleanSVEditor(node) {
            $('[data-slickgrid]').each(function() {
                $(this).data('data-slickgrid').destroy();
            });
            $(node).empty();
        }

        function createSVEditor(item, node) {
            cleanSVEditor(node);
            var timestamp = (new Date()).getTime(), container = $('<div id="svEditor' + timestamp + '" style="width:100%"></div>').appendTo(node), svGrid;

            toSV(
                    item,
                    function(artifacts, active) {
                        var slickGridId = "sv" + timestamp, svStatusId = "#svStatus" + timestamp, plugin = new Slick.CheckboxSelectColumn();

                        $(container).html(securityEditorTemplate.render({ "timestamp" : timestamp }));

                        svGrid = new Insight.Table(slickGridId, artifacts, {
                            resizeFn : $.noop,
                            height : '220px',
                            width : '100%',
                            disableFilter : true,
                            selectable : true,
                            dataProcessor : function(data) {
                                var source, reference;
                                for ( var i = 0; i < data.length; i++) {
                                    data[i]['id'] = i;
                                    data[i]['_score'] = isNullOrUndefined( data[i]['score'] ) ? "Unscored" : '' + Math.floor(data[i]['score']);

                                    source = data[i]['source'];
                                    reference = data[i]['reference'];
                                    data[i]['_reference'] = (isNullOrUndefined(source) || reference.toUpperCase().indexOf(source.toUpperCase()) === 0) ? reference : source + "-" + reference;
                                }
								if (active) {
									setTimeout(function(){
										$.each(data, function(dataIndex, dataItem) {
											if (dataItem.source === item.source && dataItem.reference === item.reference) {
												svGrid.table.setSelectedRows([ svGrid.table.getData().getRowById(dataItem.id) ]);
												return false;
											}
										});
									}, 1);
								}
                                return data;
                            },
                            defaultSort : {
                                columnId : '_score',
                                sortAsc : false
                            },
                            plugins : [ plugin ],
                            columns : [ plugin.getColumnDefinition(), {
                                id : "_score",
                                name : "Threat Level",
                                field : "_score",
                                sortable : true,
                                width : 90,
                                minWidth : 90,
                                toolTip : "'Threat Level' highlights the CVSS (Common Vulnerability Scoring System, version 2) base score for each listed vulnerability.",
                                styleFn : function(row, cell, value, columnDef, dataContext) {
                                    return 'nopad';
                                },
                                sortFn : function(dataRow1, dataRow2) {
                                    var a = dataRow1['_score'], b = dataRow2['_score'];
                                    if (isNaN(a) === isNaN(b)) {
                                        return ((a < b) ? -1 : ((a > b) ? 1 : 0));
                                    }
                                    return a.length < b.length ? 1 : -1;
                                },
                                formatter : function(row, cell, value, columnDef, dataContext) {
                                    var colorCls;
                                    if (value >= 8) {
                                        colorCls = ' criticalScore';
                                    } else if (value >= 4) {
                                        colorCls = ' severeScore';
                                    } else {
                                        colorCls = ' moderateScore';
                                    }
                                    return '<div class="' + colorCls + '">' + (value || "&nbsp;") + '</div>';
                                }
                            }, {
                                id : "problemCode",
                                name : "Problem Code",
                                field : "_reference",
                                sortable : true,
                                width : 90,
                                minWidth : 90,
                                formatter : function(row, cell, value, columnDef, dataContext) {
                                    var reference = dataContext['_reference'], url = dataContext["url"];
                                    if (isNullOrUndefined(reference)) {
                                        return '';
                                    }
                                    return '<a href="' + url + '" target="_blank">' + reference + '</a>';
                                }
                            }, {
                                id : 'status',
                                name : 'Status',
                                field : 'status',
                                sortable : true,
                                width : 90,
                                minWidth : 90,
                                sortFn : function(a, b) {
                                    a = isNotNullOrUndefined(a.status) ? a.status : 'Open';
                                    b = isNotNullOrUndefined(b.status) ? b.status : 'Open';
                                    return a > b ? 1 : a < b ? -1 : 0;
                                },
                                formatter : function(row, cell, value, columnDef, dataContext) {
                                    return isNotNullOrUndefined(value) ? value : 'Open';
                                }
                            } ]
                        });

                        $('#' + slickGridId + 'Table').data('data-slickgrid', svGrid.table).attr('data-slickgrid', true).click(function(e) {
                            if (e.target.nodeName === 'A') {
                                window.open($(e.target).attr('href'), '_blank');
                            }
                            return false;
                        });

						var options = {
								"timestamp" : timestamp,
								"width" : 300,
								"callback" : function(errorMsg) {
									trackEvent('component_info_panel', 'update_security');
									if (isNullOrUndefined(errorMsg)) {
										updateComponentTable();
										var items = svGrid.table.getSelectedRows();
                                        if (items.length == 1) {
                                            addSuccessMessage('Updated ' + items.length + ' security vulnerability.');
                                        } else if (items.length > 1) {
                                            addSuccessMessage('Updated ' + items.length + ' security vulnerabilities.');
                                        }
									} else {
										addErrorMessage(errorMsg);
									}
								},
								"dataViews" : [svGrid.table.getData()],
								"grid" : svGrid.table,
								"artifacts" : []
							},
							securityEditor;
						if (active) {
							options.dataViews.push(_grid.getData());
						}
						securityEditor = new InsightDatatable.SecurityEditor(options);
						securityEditor.show('#editor' + timestamp);
                    },
                    getErrorFn(node, function() {
						createSVEditor(item,node);
                    }));
        }

        function toLicense(item, callback, errorCallback) {
            load(item, 'licenses.json', 'effectiveLicenseThreat', function(data, active) {
                for ( var i = 0; i < data.aaData.length; i++) {
                    if (data.aaData[i].groupId == item.groupId && data.aaData[i].artifactId == item.artifactId && data.aaData[i].version == item.version) {
                        callback.call(this, data.aaData[i], active);
                        break;
                    }
                }
            }, callback, errorCallback);
        }

        function toSV(item, callback, errorCallback) {
            load(item, 'security.json', 'reference', function(data, active) {
                var security = [];
                for ( var i = 0; i < data.aaData.length; i++) {
                    if (data.aaData[i].groupId == item.groupId && data.aaData[i].artifactId == item.artifactId && data.aaData[i].version == item.version) {
                        security.push($.extend({}, data.aaData[i], {
                            id : i
                        }));
                    }
                }
                callback.call(this, security, active);
            }, callback, errorCallback);
        }

        function load(item, file, property, fn, callback, errorCallback) {
            if (isNotNullOrUndefined(item[property])) {
                fn.call(this, {
                    aaData : _grid.getData().getItems()
                }, true);
            } else {
                $.getJSON(file, function(data){
					fn.call(this, data, false);
                }).error(errorCallback);
            }
        }

        function addErrorMessage(msg) {
          message(msg).addClass('alert-error').append('<strong>Error: </strong>', $('<span></span>').text(msg));
        }

        function addSuccessMessage(msg) {
          var msgNode = message(msg).addClass('alert-success').append($('<span></span>').text(msg));
          setTimeout(function(){
            msgNode.fadeOut('fast', function(){
              msgNode.remove();
            });
          }, 8000);
          return msgNode;
        }

        function message(msg) {
          $('#' + currentView + ' .alert').remove(); // limited space in CIP, don't allow messages to stack
          var msgNode = $('<div class="alert"><button class="close" data-dismiss="alert">&times;</button></div>');
          $('#' + currentView + ' > div').prepend(msgNode);
          return msgNode;
        }

        $.extend(this, {
            "init" : init,
            "destroy" : destroy
        });
    }
}());
