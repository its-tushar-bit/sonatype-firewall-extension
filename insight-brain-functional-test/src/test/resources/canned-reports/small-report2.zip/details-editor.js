/**
 * @license Copyright (c) 2012-2013 Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/rhc/pro/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
/*global document, Hogan, $ */
(function($) {
  var securityKeyColumns = ['source', 'reference'],
    bomKeyColumns = ['hash'],
    licenseEditorTemplate,
    svEditorTemplate;

  $(document).ready(function() {
    licenseEditorTemplate = Hogan.compile($('#licenseEditorTemplate').html());
    svEditorTemplate = Hogan.compile($('#svEditorTemplate').html());
  });

  function LicenseEditor(options) {
    options = $.extend({ "timestamp": new Date().getTime() }, options);
    var _artifacts = options.artifacts,
        licenseStatusId = "#licenseselect" + options.timestamp,
        licenseId = '#license' + options.timestamp,
        _node = null,
        _licenseNodes = null,
        _artifactLicenseDeferred = $.Deferred(),
        formValidation = function() {
          var status = $('option:selected', licenseStatusId).val(),
              comment = $.trim($('textarea', _node).val()),
              license = $('option:selected', licenseId).val(),
              valid = (license && (status === 'Overridden' || status === 'Selected')) ||
                  (!license && !(status === 'Overridden' || status === 'Selected')),
              statusChanged = status !== (_artifacts[0].status || 'Open'),
              newComment = comment.length > 0,
              overrideStatus = (status === 'Overridden' || status === 'Selected'),
              licenseChanged = license &&
                  (!_artifacts[0].overriddenLicenses || _artifacts[0].overriddenLicenses[0] !== license);

          if (valid && (newComment || statusChanged || (overrideStatus && licenseChanged))) {
            $('button[data-type=update]', _node).removeAttr('disabled');
          }
          else {
            $('button[data-type=update]', _node).attr('disabled', 'disabled');
          }
        };

    options.single = (Brain.ci.getArtifactLicensesUrl && options.single); // backwards compatability

    if (options.grid) {
      options.grid.onSelectedRowsChanged.subscribe(artifactsChanged);
    }
    if (options.single) {
      $.getJSON(Insight.toBrain(Brain.ci.getArtifactLicensesUrl($.extend({ appId: applicationId },
              _artifacts[0])))).success(function(artifactLicenses) {
        _artifactLicenseDeferred.resolve(artifactLicenses);
      }).error(function() {
            // TODO show a message
          });
    }

    function artifactsChanged() {
      _artifacts = [];
      $.each(options.grid.getSelectedRows(), function(index, item) {
        _artifacts.push(options.grid.getData().getItem(item));
      });
      if (_artifacts.length === 1) {
        $('input,textarea,select', _node).change(formValidation).keyup(formValidation).focusout(formValidation);
      }
      else {
        $('input,textarea,select', _node).unbind('change').unbind('keyup').unbind('focusout');
        $('button[data-type=update]', _node).removeAttr('disabled');
      }
    }

    function destroy() {
      if (options.grid) {
        options.grid.onSelectedRowsChanged.unsubscribe(artifactsChanged);
      }
    }

    function update(e) {
      var me = this,
          mask = {},
          dataView;
      e.preventDefault();
      $(me).attr('disabled', 'disabled');

      $('select', _node).each(function(index) {
        if (index === 0) {
          mask.status = $(this).val();
        }
        else {
          var overridden = !$(this).prop('disabled');
          mask.overriddenLicenses = overridden ? [$(this).val()] : null;
          mask.overriddenLicenseThreat = overridden ? InsightDatatable.getLicenseThreatLevelFromArray(mask.overriddenLicenses) : null;
        }
      });
      mask.comment = $('textarea', _node).val();

      updateLicenses({
        mask: mask,
        callback: function(errorMsg) {
          if (Insight.util.isNotNullOrUndefined(errorMsg)) {
            $(me).removeAttr('disabled');
          }
          if (Insight.util.isNotNullOrUndefined(options.callback)) {
            options.callback.apply(this, arguments);
          }
        },
        dataView: options.dataView,
        items: _artifacts
      });
    }

    function show(node) {
      _node = node;
      $(_node).html(licenseEditorTemplate.render(options));
      $('button[data-type=update]', _node).click(update);
      $('button[data-type=cancel]', _node).click(function(e) {
        e.preventDefault();
        if (options.cancelCallback) {
          options.cancelCallback.apply(this);
        }
      });

      if (_artifacts.length === 1) {
        $('button[data-type=update]', _node).attr('disabled', 'disabled');
        $('input,textarea,select', _node).change(formValidation).keyup(formValidation).focusout(formValidation);
        if (Insight.util.isNotNullOrUndefined(_artifacts[0].status)) {
          $('[value=' + _artifacts[0].status + ']', _node).attr('selected', true);
        }
      }
      $(licenseStatusId, _node).css("width", options.width);

      $(licenseStatusId, _node).change(function() {
        var combo = $(this),
            selectedLicense = $(licenseId).val() ||
                (_artifacts[0].overriddenLicenses && _artifacts[0].overriddenLicenses[0]);

        switch (combo.val()) {
          case 'Selected' :
            $('option', licenseId).detach();
            $(licenseId, _node).attr('disabled', true);
            _artifactLicenseDeferred.done(function(artifactLicenses) {
              if (combo.val() === 'Selected' && artifactLicenses.length > 0) {
                InsightDatatable.loadLicenseThreats(function(licenseThreats) {
                  var selectableLicenses = {};
                  // Create License -> Threat map
                  $.each(artifactLicenses, function(key, license) {
                    selectableLicenses[license.licenseName] = licenseThreats[license.licenseName];
                  });
                  InsightDatatable.populateLicenseCombo($(licenseId, _node), selectableLicenses);

                  if (Insight.util.isNotNullOrUndefined(selectedLicense)) {
                    $('option[value="' + selectedLicense + '"]', licenseId).attr('selected', 'selected');
                  }
                  $(licenseId, _node).removeAttr('disabled');
                });
              }
            });
            break;
          case 'Overridden':
            $('option', licenseId).detach();
            _licenseNodes.appendTo(licenseId);
            $(licenseId, _node).removeAttr('disabled');
            break;
          default :
            $('option', licenseId).detach();
            $(licenseId, _node).attr('disabled', true);
        }
        if (Insight.util.isNotNullOrUndefined(selectedLicense)) {
          $('option[value="' + selectedLicense + '"]', licenseId).attr('selected', 'selected');
        }
        formValidation();
      });

      loadLicenses(function(licenses) {
        var licenseCombo = $(licenseId, _node),
            userLicense = null;

        InsightDatatable.populateLicenseCombo(licenseCombo, licenses);
        _licenseNodes = $('option', licenseCombo);

        if (_artifacts.length === 1) {
          if (Insight.util.isNotNullOrUndefined(_artifacts[0].overriddenLicenses) &&
              _artifacts[0].overriddenLicenses.length > 0) {
            $('option', licenseCombo).each(function() {
              if ($(this).val() === _artifacts[0].overriddenLicenses[0]) {
                $(this).attr('selected', true);
              }
            });
          }

          $(licenseStatusId, _node).trigger('change'); // Sets enablement
        }
        $(licenseCombo, _node).css("width", options.width);
      });
    }

    $.extend(this, {
      'destroy': destroy,
      'show': show
    });
  }

  function SecurityEditor(options) {
    options = $.extend({ "timestamp": new Date().getTime() }, options);
    var _artifacts = options.artifacts,
        _node;

    function validate() {
      if (_artifacts.length === 0) {
        $('button[data-type=update]', _node).attr('disabled', 'disabled');
      }
      else {
        $('button[data-type=update]', _node).removeAttr('disabled');
      }
    }

    function artifactsChanged() {
      _artifacts = [];
      $.each(options.grid.getSelectedRows(), function(index, item) {
        _artifacts.push(options.grid.getData().getItem(item));
      });
      validate();
    }

    if (options.grid) {
      options.grid.onSelectedRowsChanged.subscribe(artifactsChanged);
    }

    function destroy() {
      if (options.grid) {
        options.grid.onSelectedRowsChanged.unsubscribe(artifactsChanged);
      }
    }

    function update(e) {
      var mask = {};
      e.preventDefault();

      mask.status = $('select', _node).val();
      mask.comment = $('textarea', _node).val();

      updateSecurity({
        mask: mask,
        dataView: options.dataViews[0],
        items: _artifacts,
        callback: function(errorMsg) {
          //if there is an error, no need to do any view updates
          if (!Insight.util.isNotNullOrUndefined(errorMsg)) {
            for (var i = 1; i < options.dataViews.length; i++) {
              options.dataViews[i].beginUpdate();
              $.each(_artifacts, function(index, updatedItem) {
                $.each(options.dataViews[i].getItems(), function(index, item) {
                  if (updatedItem.source !== item.source || updatedItem.reference !== item.reference
                    || updatedItem.componentIdentifier.format !== item.componentIdentifier.format) {
                    return;
                  }
                  for (var property in updatedItem.componentIdentifier.coordinates) {
                    if (updatedItem.componentIdentifier.coordinates.hasOwnProperty(property)) {
                      if (updatedItem.componentIdentifier.coordinates[property] !== item.componentIdentifier.coordinates[property]) {
                        return;
                      }
                    }
                  }
                  options.dataViews[i].updateItem(item.id, $.extend({}, item, mask));
                  return false;
                });
              });
              options.dataViews[i].endUpdate();
            }
          }
          
          if (Insight.util.isNotNullOrUndefined(options.callback)) {
            options.callback.apply(this, arguments);
          }
        }
      });
    }

    function show(node) {
      _node = node;
      $(_node).html(svEditorTemplate.render(options));
      $('button[data-type=update]', _node).click(update);

      $('button[data-type=cancel]', _node).click(function(e) {
        e.preventDefault();
        if (options.cancelCallback) {
          options.cancelCallback.apply(this);
        }
      });
      $('#svStatus' + options.timestamp, _node).css("width", options.width);
      validate();
    }

    $.extend(this, {
      'destroy': destroy,
      'show': show
    });
  }

  function updateItems(dataView, items, mask, keyColumns, file, callback) {
    var modifiedRows = [],
        filter = [];

    $.each(items, function(itemIndex, item) {
      var dataItem = $.extend({}, item);
      $.each(mask, function(key, value) {
        dataItem[key] = value;
      });
      dataItem.modified = true;
      modifiedRows.push(dataItem);
    });

    $.merge(filter, keyColumns);
    $.each(mask, function(key, value) {
      filter.push(key);
    });

    var commitFn = function() {
      dataView.beginUpdate();
      $.each(modifiedRows, function(index, dataItem) {
        dataView.updateItem(dataItem.id, dataItem);
      });
      dataView.endUpdate();
      Insight.updateSummary();

      callback();
    };

    // non-critical request to flag rows as modified in UI
    $.ajax({
      type: 'POST',
      url: '../augmentData/bom.json',
      data: buildJson(modifiedRows, $.merge(['modified'], bomKeyColumns)),
      beforeSend: parent.beforeSendAugmentedData
    });

    // send request
    $.ajax({
      type: 'POST',
      url: '../augmentData/' + file,
      data: buildJson(modifiedRows, filter),
      beforeSend: parent.beforeSendAugmentedData
    }).success(commitFn).error(function(resp, type, message) {
          message = Insight.util.getErrorMessage(resp);
          callback(message);
        });
  }

  function buildJson(dataItemArray, filter) {
    var jsonArray = [];
    for (var i = 0; i < dataItemArray.length; i++) {
      var dataItem = dataItemArray[i];
      var jsonItem = {
        componentIdentifier: dataItem.componentIdentifier
      };
      for (var i = 0; i < filter.length; i++) {
        jsonItem[filter[i]] = dataItem[filter[i]];
      }
      jsonArray.push(jsonItem);
    }
    return JSON.stringify(jsonArray);
  };

  var licenses = null,
      licenseReqActive = false,
      licenseLoadCallbacks = [];

  function loadLicenses(callback, table) {
    if (Insight.util.isNotNullOrUndefined(licenses)) {
      callback.apply(null, [licenses]);
      return;
    }
    licenseLoadCallbacks.push(callback);
    if (!licenseReqActive) {
      licenseReqActive = true;
      $.getJSON('licenselist.json').success(function(jsonData) {
        licenses = jsonData.aaData;
        $.each(licenseLoadCallbacks, function(index, item) {
          item.apply(null, [licenses]);
        });
      }).error(function(resp, type, msg) {
        // I don't like this but not sure what to do?
        var table = InsightDatatable.getActiveTable();
        msg = Insight.util.getErrorMessage(resp);
        if (table !== null) {
          table.addError('Loading known licenses: ' + msg);
        }
        else if (console) {
          console.log('Error loading known licenses: ' + msg);
        }
      });
    }
  }

  function populateLicenseCombo(combo, licenses, selectedLicense) {
    $(combo).empty();
    var sortedLicenses = [];
    $.each(licenses, function(license, category) {
      sortedLicenses.push(license);
    });
    sortedLicenses.sort(function(a, b) {
      a = a.toUpperCase();
      b = b.toUpperCase();
      return a > b ? 1 : a < b ? -1 : 0;
    });
    $.each(sortedLicenses, function(index, license) {
      var optionnode = $('<option></option>').text(license).val(license);
      if (license === selectedLicense) {
        optionnode.attr('selected', 'selected');
      }
      $(combo).append(optionnode);
    });
  }

  function addLicenseTableEditor(table) {

    var grid = table.table,
        columns = grid.getColumns(),
        removeCallback = function() {
          $('#licensestateselect').val('Open').attr('selected', true);
          $('#licenseselect').attr('disabled', 'disabled');
          $('textarea', '#licenseEditor').val('');
          table.updateHeight();
        },
        bulkEditor = new Slick.BulkEditor({
          editNode: $('#licenseEditor'),
          editor: new LicenseEditor({
            "artifacts": [],
            "width": 650,
            "cancel": true,
            "grid": grid,
            "dataView": grid.getData(),
            "callback": function(errorMsg) {
              if (Insight.util.isNotNullOrUndefined(errorMsg)) {
                table.addError(errorMsg);
              }
              else {
                var items = grid.getSelectedRows();
                Insight.updateSummary();
                if (items.length == 1) {
                  table.addSuccess('Updated license for ' + items.length + ' component.', 60);
                }
                else if (items.length > 1) {
                  table.addSuccess(grid, 'license', 'Updated license for ' + items.length + ' components.', 60);
                }
                $('#licenseEditor').slideUp({
                  complete: function() {
                    $(this).empty();
                  },
                  step: function() {
                    table.updateHeight();
                  }
                });
              }
            },
            "cancelCallback": function(affectedRows) {
              $('#licenseEditor').empty().hide();
              table.updateHeight();
            }
          }),
          openCallback: function() {
            table.updateHeight();
          }
        }),
        updateCallback;

    columns = $.merge([bulkEditor.getColumnDef()], columns);
    columns[0].filterable = false;

    grid.setSelectionModel(new Slick.RowSelectionModel());
    grid.getData().syncGridSelection(grid, true);
    grid.setColumns(columns);

    grid.registerPlugin(bulkEditor);
  }

  function addSecurityTableEditor(table) {

    var grid = table.table,
        columns = grid.getColumns(),
        removeCallback = function() {
          $('#securitystateselect').val('Open').attr('selected', true);
          $('textarea', '#securityEditor').val('');
          $('select', '#securityEditor').val('New');
          table.updateHeight();
        },
        bulkEdit = new Slick.BulkEditor({
          editNode: $('#securityEditor'),
          editor: new SecurityEditor({
            "width": 650,
            "grid": grid,
            "cancel": true,
            "artifacts": [],
            "dataViews": [grid.getData()],
            "callback": function(errorMsg) {
              if (Insight.util.isNotNullOrUndefined(errorMsg)) {
                table.addError(errorMsg);
              }
              else {
                var items = grid.getSelectedRows();
                Insight.updateSummary();
                if (items.length == 1) {
                  table.addSuccess('Updated ' + items.length + ' security vulnerability.', 60);
                }
                else if (items.length > 1) {
                  table.addSuccess('Updated ' + items.length + ' security vulnerabilities.', 60);
                }
                $('#securityEditor').slideUp({
                  complete: function() {
                    $(this).empty();
                  },
                  step: function() {
                    table.updateHeight();
                  }
                });
              }
            },
            "cancelCallback": function(affectedRows) {
              $('#securityEditor').empty().hide();
              table.updateHeight();
            }
          }),
          openCallback: function() {
            table.updateHeight();
          }
        });
    columns = $.merge([bulkEdit.getColumnDef()], columns);
    columns[0].filterable = false;

    grid.setSelectionModel(new Slick.RowSelectionModel());
    grid.getData().syncGridSelection(grid, true);
    grid.setColumns(columns);
    grid.registerPlugin(bulkEdit);
  }

  function updateLicenses(options) {
    options = $.extend({ dataView: null, items: [], mask: {}, callback: $.noop }, options);
    if (!$.isArray(options.items)) {
      options.items = [options.items];
    }
    updateItems(options.dataView, options.items, options.mask, {}, 'licenses.json', options.callback);
  }

  function updateSecurity(options) {
    options = $.extend({ dataView: null, items: [], mask: {}, callback: $.noop }, options);
    if (!$.isArray(options.items)) {
      options.items = [options.items];
    }
    updateItems(options.dataView, options.items, options.mask, securityKeyColumns, 'security.json', options.callback);
  }

  function updateBom(options) {
    options = $.extend({ dataView: null, items: [], mask: {}, callback: $.noop }, options);
    if (!$.isArray(options.items)) {
      options.items = [options.items];
    }
    updateItems(options.dataView, options.items, options.mask, bomKeyColumns, 'bom.json', options.callback);
  }

  // register namespace
  $.extend(true, window, {
    "InsightDatatable": {
      "addSecurityTableEditor": addSecurityTableEditor,
      "addLicenseTableEditor": addLicenseTableEditor,
      "populateLicenseCombo": populateLicenseCombo,
      "loadLicenses": loadLicenses,
      "LicenseEditor": LicenseEditor,
      "SecurityEditor": SecurityEditor,
      "updateLicenses": updateLicenses,
      "updateSecurity": updateSecurity,
      "updateBom": updateBom
    }
  });
})(jQuery);
