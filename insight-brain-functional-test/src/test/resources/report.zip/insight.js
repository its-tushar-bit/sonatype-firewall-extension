/**
 * @license Copyright (c) 2011-2012 Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/rhc/pro/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
/*global $, window, Insight */
/*jslint plusplus:true */
(function() {
  "use strict";

  $.extend(true, window, {
    'Insight': {
      'toBrain': function(url) {
        if (url.charAt(0) === '/') {
          return '../brain' + url;
        }
        return '../brain/' + url;
      }
    }
  });
}());

(function() {
  "use strict";

  function isNullOrUndefined(obj) {
    return obj === null || typeof obj === 'undefined';
  }

  function isNotNullOrUndefined(obj) {
    return !isNullOrUndefined(obj);
  }

  function getQueryParameter(name) {
    var search = window.location.search.length > 0 ? window.location.search.substring(1).split('&') : [],
        data = null,
        i = null;
    name = name.toLowerCase();

    $.each(search, function(index, item) {
    });
    for (i = 0; i < search.length; i++) {
      data = search[i].split('=');
      if (data[0].toLowerCase() === name) {
        return data[1];
      }
    }
  }

  function enableTooltip(elements) {
    $(elements).each(function() {
      var me = this;
      var offset = $(me).attr('data-gravity-offset') || 0;
      if (offset) {
        offset = parseInt(offset);
      }
      $(this).tipsy({fade: true, gravity: $(me).attr('data-gravity'), offset: offset, html: true, opacity: 1.0, delayOut: 0, title: 'data-tooltip' });
    });
  }

  function getErrorMessage(xhr) {
    var message = '';
    if (xhr.status === 0 || xhr.status >= 1000) {
      message = 'Network error while contacting server';
    }
    else if (xhr.responseText && (xhr.getResponseHeader('Content-Type') || '').indexOf('text/plain') >= 0) {
      message = xhr.responseText;
    }
    else if (xhr.statusText) {
      message = xhr.statusText;
    }
    else {
      message = 'Error ' + xhr.status;
    }
    return message;
  }

  $.extend(true, window, {
    'Insight': {
      'util': {
        'enableTooltip': enableTooltip,
        'getErrorMessage': getErrorMessage,
        'getQueryParameter': getQueryParameter,
        'isNullOrUndefined': isNullOrUndefined,
        'isNotNullOrUndefined': isNotNullOrUndefined
      }
    }
  });
}());

// Brain client for backwards compatibility with Brain server 1.0
(function() {
  "use strict";
  var features = {};

  if (Insight.util.isNullOrUndefined(window.Brain)) {
    $.getJSON('../brain/rest/features').success(function(data) {
      $.each(data, function(key, item) {
        features[item.toLowerCase()] = true;
      });
    });

    $.extend(true, window, {
      'Brain': {
        "hasFeature": function(feature) {
          return features[feature.toLowerCase()] === true;
        },
        'getVersion': function() {
          return false;
        }
      }
    });
  }
}());

// Application startup
(function() {
  var fullTour = false;

  window.demoMode = false;

  function enableDemoMode() {
    window.demoMode = true;
    demoArtifactUrl = 'https://insight.sonatype.com/rest/ci/artifact/';
  }

  $(document).ready(function() {
    InsightDatatable.updateSummary();

    $('button[data-containerid]').click(function(i) {
      if (!$(this).hasClass('active')) {
        var containerId = $(this).data('containerid'),
            table;
        if (freemium) {
          Insight.stopTours();
        }
        // hide
        $('[data-container]').css('display', 'none');
        // show
        $('#' + containerId).css('display', '');

        InsightDatatable.destroyActiveTable();

        switch (containerId) {
          case 'securitycontainer' :
            table = InsightDatatable.createSecurityTable({ "headerRowHeight": 30 });
            table.addLoadListener(function() {
              InsightDatatable.addSecurityTableEditor(table);
            });
            if (freemium) {
              Insight.startSVTour();
            }
            break;
          case 'licensecontainer' :
            table = InsightDatatable.createLicenseTable({ "headerRowHeight": 30 });
            table.addLoadListener(function() {
              InsightDatatable.addLicenseTableEditor(table);
            });
            if (freemium) {
              Insight.startLicenseTour();
            }
            break;
          case 'componentcontainer' :
            InsightDatatable.createComponentTable();
            if (freemium && fullTour) {
              Insight.startComponentTour();
            }
            break;
          case 'summary':
            if (freemium && fullTour) {
              Insight.startSummaryTour();
            }
            break;
        }
      }
    });

    Insight.util.enableTooltip($('[data-tooltip]'));

    var policyReevaluationAnchor = $('[data-action="reevaluatePolicy"]');
    if (!Brain.hasFeature('reevaluate-policy')) {
      policyReevaluationAnchor.hide();
    }
    else {
      policyReevaluationAnchor.click(function() {
        policyReevaluationAnchor.find('i').attr('class', 'icon-white icon-time');
        $.getJSON('../reevaluatePolicy').success(function() {
          policyReevaluationAnchor.find('i').attr('class', 'icon-white icon-refresh');
          location.reload();
        }).error(function() {
              $('.btn-group:eq(1)').after('<div class="alert alert-error" style="margin:5px 0"><button class="close" data-dismiss="alert">&times;</button>There has been an error reevaluating policy. Try running the report again.</div>');
            });
      });
    }

    if (freemium) {
      $.support.cors = true; // for IE

      $.getJSON('${purchaseDimensionUrl}', function(data) {
        $('#purchase').css('width', data.width + 'px');
        $('#purchase .modal-body').css('height', data.height + 'px').css('max-height', data.height + 'px');
      });

      $('body').on('click', 'a[data-action=buypro]', function(event) {
        var purchaseNode = $('#purchase');
        purchaseNode.css('margin-left', -purchaseNode.width() / 2)
            .css('margin-top', -purchaseNode.height() / 2);

        $('iframe', purchaseNode).attr('src', '${purchaseUrl}');
        purchaseNode.modal({ backdrop: 'static' });
        return false;
      });
    }

    if ($.browser.msie && $.browser.version < 9) {
      $('.btn-group:eq(1)').after('<div class="alert alert-error" style="margin:5px 0"><button class="close" data-dismiss="alert">&times;</button>You are using older version of Internet Explorer (IE). You may notice degraded performance and/or functionality. To address this, download and install the latest version of IE, or other modern browser (e.g. Chrome, Firefox)</div>');
    }
  });
}());