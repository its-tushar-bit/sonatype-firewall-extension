/**
 * @license Copyright (c) 2011-2012 Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/rhc/pro/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
/*jshint sub:true */
(function() {
	var blue = '#6e99d0',
		grey = '#d9dade',
		orange = '#f7941d',
		yellow = '#fedf15',
		red = '#ee1b24',
		white = '#ffffff',
		licenseColors = [red, orange, yellow, blue,white],
		securityColors = [red, orange, yellow, white];

	function isNullOrUndefined(obj) {
		return obj === null || typeof obj === 'undefined';
	}

	function isNotNullOrUndefined(obj) {
		return !isNullOrUndefined(obj);
	}

	function numberCompare(number1, number2) {
        return number1 - number2;
    }

    function getLicenseTotal(counters) {
        return counters["COPYLEFT"] + counters["NON-STANDARD"] +
               counters["NOT-PROVIDED"] + counters["WEAKCOPYLEFT"] +
               counters["LIBERAL"];
    }

    function getSecurityTotal(counters) {
        return counters["Critical"] + counters["Severe"] +
               counters["Moderate"] + (counters["None"] ? counters["None"] : 0);
    }

    var versionComparison = {
        preReleaseStrings : new Array("alpha", "beta", "milestone", "rc", "snapshot"),
        isPrerelease : function(val) {
            val = val.toLowerCase();
            if (isNotNullOrUndefined(val) && (val.length == 1 || !isNaN(parseFloat(val.charAt(1))))) {
                switch (val.charAt(0)) {
                case 'a':
                case 'b':
                case 'm':
                    return true;
                }
            }
            for ( var i = 0; i < this.preReleaseStrings.length; i++) {
                if (val.substr(0, this.preReleaseStrings[i].length) == this.preReleaseStrings[i]) {
                    return true;
                }
            }
            return false;
        },
        versionItemCompare : function(a, b) {
            if (isNullOrUndefined(a)) {
                return -this.versionItemCompare(b, a);
            }
            var aInt = parseInt(a,10), bInt = parseInt(b,10);
            if (isNullOrUndefined(b)) {
                return this.isPrerelease(a) ? -1 : 1;
            } else if (!isNaN(aInt) && !isNaN(bInt)) {
                return aInt == bInt ? 0 : (aInt > bInt ? 1 : -1);
            } else if (!isNaN(aInt) || !isNaN(bInt)) {
                return isNaN(aInt) ? (this.isPrerelease(a) ? -1 : 1) : (this.isPrerelease(b) ? 1 : -1);
            } else {
                return ((a < b) ? -1 : ((a > b) ? 1 : 0));
            }
        },
        compare : function(a, b) {
            if (isNullOrUndefined(a)) {
                if (isNullOrUndefined(b)) {
                    return 0;
                } else {
                    return -1;
                }
            }
            if (isNullOrUndefined(b)) {
                return 1;
            }
            var aMatches = a.match(/(\w+)/g), bMatches = b.match(/(\w+)/g);

            for ( var i = 0; i < Math.max(aMatches.length, bMatches.length); i++) {
                switch (this.versionItemCompare(aMatches[i], bMatches[i])) {
                case 1:
                    return 1;
                case -1:
                    return -1;
                }
            }
            return 0;
        }
    };

	function getQueryParameter(name) {
		var search = window.location.search.length > 0 ? window.location.search.substring(1).split('&') : [],
			data;
		name = name.toLowerCase();

		for (var i=0; i<search.length; i++) {
			data = search[i].split('=');
			if (data[0].toLowerCase() === name) {
				return data[1];
			}
		}
	}

	function isReadOnly() {
		return getQueryParameter('readonly') !== 'false';
	}
	
	function isInfoPanelShown() {
        var firstEditVersion = '2.2', currentVersion = getQueryParameter('version');
		
		return currentVersion && versionComparison.compare(firstEditVersion, currentVersion) < 1;
	}

    function dedupLicenses(licenses1, licenses2) {
        var deduped = [];

        for ( var i = 0 ; i < licenses2.length ; i++ ) {
            //Not Provided can be in both lists, but shown with different data
            if ('Not Provided' === licenses2[i] || licenses1.indexOf(licenses2[i]) == -1) {
                deduped.push(licenses2[i]);
            }
        }

        return deduped;
    }

    function renderLicenses(licenses) {
        return isNotNullOrUndefined(licenses) && licenses.length > 0 ? licenses.join(', ') : '';
    }

    var firstRun = true;
    var offset = (jQuery.browser && jQuery.browser.mozilla && parseFloat(jQuery.browser.version) < 4) ? 60 : 65;
    function getHeight(node) {
		var windowHeight = window.innerHeight ? window.innerHeight : $(document).height(),
			containerTop = $(node).offset().top,
			pagerHeight = $('#' + node.attr('id') + 'Pager').height(),
			val;
        if (firstRun) {
            firstRun = false;
            containerTop += 5;
        }
        val = Math.max(150, windowHeight - containerTop - offset - pagerHeight);
        return val;
    }

    function updateTableHeight(table, id) {
		if (isNotNullOrUndefined(table)) {
			var node = $('#' + id + 'Table');
			node.css('height', getHeight(node) + 'px');
			table.resizeCanvas();
		} else {
            if ( securityTable ) {
                InsightDatatable.updateTableHeight(item, 'security');
            }
            if ( licenseTable ) {
                InsightDatatable.updateTableHeight(item, 'license');
            }
            if ( componentTable ) {
                InsightDatatable.updateTableHeight(item, 'component');
            }
            if ( similarityTable ) {
                InsightDatatable.updateTableHeight(item, 'similarity');
            }
            if ( auditTable ) {
                InsightDatatable.updateTableHeight(item, 'audit');
            }
		}
    }

    var effectiveLicenseOrder = ["UNKCAT", "LIBERAL", "WEAKCOPYLEFT", "NOT-PROVIDED", "NON-STANDARD", "COPYLEFT"];
    function getEffectiveLicenseOrder() {
		return effectiveLicenseOrder;
    }

    function effectiveLicenseSortFn(dataRow1, dataRow2) {
        var x = getEffectiveLicenseOrder().indexOf(dataRow1.effectiveLicenseThreat),
            y = getEffectiveLicenseOrder().indexOf(dataRow2.effectiveLicenseThreat);

        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    }

    function getLicenseThreatImg(value) {
        var result = '';
        switch (value) {
        case "COPYLEFT":
            result += '<img src="public/red.png" alt="COPYLEFT"/>';
            break;
        case "NON-STANDARD":
            result += '<img src="public/orange.png" alt="NON-STANDARD"/>';
            break;
        case "NOT-PROVIDED":
            result += '<img src="public/orange.png" alt="NOT-PROVIDED"/>';
            break;
        case "WEAKCOPYLEFT":
            result += '<img src="public/yellow.png" alt="WEAKCOPYLEFT"/>';
            break;
        case "LIBERAL":
            result += '<img src="public/blue.png" alt="LIBERAL"/>';
            break;
        default:
            result += '<img src="public/grey.png" alt="UNKCAT"/>';
        }
        return result;
    }

    function effectiveLicenseFormatFn(overriddenLicenses, declaredLicenses, observedLicenses) {
		if (isNotNullOrUndefined(overriddenLicenses)) {
			return renderLicenses(overriddenLicenses);
		} else {
			var declared = renderLicenses(declaredLicenses).replace("Not Provided","Not Declared"),
				observed = renderLicenses(dedupLicenses(declaredLicenses, observedLicenses)).replace("Not Provided", "No Sources");
			return declared + (observed.length > 0 ? (", " + observed) : "");
		}
    }

    function effectiveLicenseHtmlFormatFn(row, cell, value, columnDef, dataContext) {
		if (isNotNullOrUndefined(dataContext.overriddenLicenses)) {
			return getLicenseThreatImg(dataContext.overriddenLicenseThreat) + ' <i>' + renderLicenses(dataContext.overriddenLicenses) + '</i>';
		} else {
			var declared = renderLicenses(dataContext.declaredLicenses).replace("Not Provided","Not Declared"),
				observed = renderLicenses(dedupLicenses(dataContext.declaredLicenses, dataContext.observedLicenses)).replace("Not Provided", "No Sources");
			return getLicenseThreatImg(dataContext.effectiveLicenseThreat) + " <b>" + declared + "</b>" + (observed.length > 0 ? (", " + observed) : "");
		}
    }

    function message(grid, id, msg) {
        $('#'+id+'container > .alert-info').remove();

        var msgNode = $('<div class="alert alert-info"></div>');
        $('#'+id+'container').prepend(msgNode);
        msgNode.append($('<span></span>').html(msg));
        InsightDatatable.updateTableHeight(grid, id);
        return msgNode;
    }

    var securityTable, licenseTable, componentTable, similarityTable, auditTable;
    function removeSecurityTable() {
        if (isNotNullOrUndefined(securityTable)) {
            destroyTable('security', securityTable);
            securityTable = null;
        }
    }
    function removeLicenseTable() {
        if (isNotNullOrUndefined(licenseTable)) {
            destroyTable('license', licenseTable);
            licenseTable = null;
        }
    }

    function removeComponentTable() {
        if (isNotNullOrUndefined(componentTable)) {
            destroyTable('component', componentTable);
            $('#componentcontainer ul.nav a').unbind('click');
            componentTable = null;
        }
    }
    function removeSimilarityTable() {
        if (isNotNullOrUndefined(similarityTable)) {
            destroyTable('similarity', similarityTable);
            similarityTable = null;
        }
    }
    function removeAuditTable() {
        if (isNotNullOrUndefined(auditTable)) {
            destroyTable('audit', auditTable);
            auditTable = null;
        }
    }

    function destroyTable(id, table) {
        closeMessagebox(id);
        $(window).unbind('resize');
        if ( table.pager ) {
            table.pager.destroy();
            table.pager = null;
        }
        if (table.columnsResizedFn) {
            table.onColumnsResized.unsubscribe(table.columnsResizedFn);
            table.columnsResizedFn = null;
        }
        table.destroy();
    }

    function closeMessagebox(id) {
        $('#' + id + 'container .message').remove();
    }

    function openMessagebox(id, msg) {
        var container = $('#'+ id + 'container'),
            position = $('#' + id + 'Table').position(),
            message;
        if (position !== null) {
			closeMessagebox(id);
			container.append('<div class="message" style="top:' + (position.top + 70) + 'px">' + msg + '</div>');
			message = $('.message', container);
			message.css('left', (position.left + container.outerWidth()/2 - message.outerWidth()/2) + 'px');
        }
    }

    function createTable(id, data, options) {
        openMessagebox(id, 'Loading');
        var groupMetadataProvider = new Slick.Data.GroupItemMetadataProvider(),
			dataView = new Slick.Data.DataView({groupItemMetadataProvider : groupMetadataProvider}),
            filter = new Slick.Filter(),
            config = $.extend({ editable : false, enableAddRow : false, enableCellNavigation : options.enableCellNavigation, enableColumnReorder : false, enableTextSelectionOnCells : true, fullWidthRows : true, forceFitColumns : true, rowHeight : 31, explicitInitialization : true, showHeaderRow: !options.disableFilter, multiSelect: false, autoHeight: options.autoHeight, multiColumnSort: options.multiColumnSort}, options.config || {}),
            table,
            init_done = false,
            init_table,
            processData,
            key;
		if (window.location.search === '?print=true') {
			table = new PrintTable.Grid("#" + id + "Table", dataView, options.columns, config);
		} else {
			table = new Slick.Grid("#" + id + "Table", dataView, options.columns, config);
		}

        if ( options.selectable ) {
            table.setSelectionModel(new Slick.RowSelectionModel());
            dataView.syncGridSelection(table, true);
        }

        groupMetadataProvider.init(table);

        $('#'+ id + 'Table').css('height', options.height ? options.height : (getHeight($('#'+ id + 'Table')) + 'px'));

        init_table = function() {
            if (options.defaultSort) {
                if ( options.defaultSort instanceof Array ) {
                    table.setSortColumns(options.defaultSort);
                } else {
                    table.setSortColumns([options.defaultSort]);
                }
            }

            if ($.isArray(options.plugins)) {
                $.each(options.plugins, function(index, plugin){ table.registerPlugin(plugin); });
            }

            table.registerPlugin(new Slick.Sort());
            table.init();
            if (!options.disableFilter) {
                table.registerPlugin(filter);
            }
            table.registerPlugin(new Slick.Tipsy());

            var resizeFn = options.resizeFn || function () {
                if ( isNullOrUndefined(table.height) ) {
					InsightDatatable.updateTableHeight(table, id);
                }
            };

            $(window).resize(resizeFn);

            init_done = true;
        };

        processData = function(dd){
            if (!init_done){
                init_table();
            }
			if (isNotNullOrUndefined(dd)) {
				// Data processing callback
				if (options.dataProcessor) {
					dd.aaData = options.dataProcessor.call(null, dd.aaData);
				}
				dataView.beginUpdate();
				dataView.setItems(dd.aaData);
				if ( !options.disableFilter ) {
					dataView.setFilter(filter.getFilter()); // TODO is this necessary?
				}
				if ( options.groupInfo ) {
					dataView.groupBy( options.groupInfo.field, options.groupInfo.groupHeaderFn, options.groupInfo.groupingComparer );
				}
				dataView.endUpdate();
				if ( options.groupInfo && options.groupInfo.initialState == 'collapsed' ) {
					//note that we need to do a second update here to collapse the groups, as this isn't possible until the dataview
					//has been updated with the groupInfo set above
					dataView.beginUpdate();
					for (var i = 0; i < dataView.getGroups().length; i++) {
						dataView.collapseGroup(dataView.getGroups()[i].value);
					}
					dataView.endUpdate();
				}
			}

            closeMessagebox(id);
            if (isNullOrUndefined(dd) || dd.aaData.length === 0) {
                openMessagebox(id, options.emptyText ? options.emptyText : 'None');
            }
            if (!options.disablePager) {
                table.pager = new Slick.Controls.Pager(dataView, table, $("#" + id + "TablePager"));
            }
        };

        if (typeof data == 'string') {
            jQuery.getJSON(data).success(processData).error(function(){
                openMessagebox(id, 'An Error Occurred');
            });
        } else {
            processData({aaData: data});
        }

        if (!init_done){
            init_table();
        }

        return table;
    }

    function createLicenseTable(config) {
        var columns = [{
            id : "_formattedEffectiveLicenseThreat",
            name : "License Threat",
            shortName : 'Licenses',
            field : "_formattedEffectiveLicenseThreat",
            sortable : true,
            width : 200,
            sortFn : effectiveLicenseSortFn,
            formatter : effectiveLicenseHtmlFormatFn
        }, {
            id : 'groupId',
            name : 'Group',
            field : 'groupId',
            sortable : true,
            width : 300,
            cssClass : 'gridcell'
        }, {
            id : 'artifactId',
            name : 'Artifact',
            field : 'artifactId',
            sortable : true,
            width : 300,
            cssClass : 'gridcell'
        }, {
            id : 'version',
            name : 'Version',
            field : 'version',
            sortable : true,
            width : 150,
            sortFn : function(a,b){ return versionComparison.compare(a['version'], b['version']); }
        },{
			id : 'status',
			name : 'Status',
			field : 'status',
            sortable : true,
			width : 150
        }];

        var plugins = [];

        if (isInfoPanelShown()) {
			plugins.push(new Insight.InformationPanel({ sampleData: freemium }));
        }

        licenseTable =  createTable('license', 'licenses.json', {
            columns : columns,
            config : config,
            plugins : plugins,
            defaultSort : { columnId : '_formattedEffectiveLicenseThreat', sortAsc : false },
            dataProcessor : function(data){
                for (var i=0; i<data.length; i++) {
                    data[i]['id'] = i;
                    data[i].status = isNullOrUndefined(data[i].status) ? 'Open' : data[i].status;
                }

                return data;
            }
        });
        licenseTable.getData().onRowsChanged.subscribe(function(event, data) {
			var item;
			data = data.rows;
			for (var i=0; i<data.length; i++) {
				item = licenseTable.getData().getItem(data[i]);
				item['_formattedEffectiveLicenseThreat'] = effectiveLicenseFormatFn(item.overriddenLicenses, item.declaredLicenses, item.observedLicenses);
			}
        });

        if (freemium) {
            message(licenseTable, 'license', 'The data shown below is sample data. To see the license data for <b>your</b> application, <a href="#" data-action="buypro">purchase a subscription.</a>');
        }

        return licenseTable;
    }

    function createSecurityTable(config) {
        var columnGrouping = new Slick.ColumnGrouping({ columnId : "_score", style : "scoreCol" }),
            scoreStyler = columnGrouping.getCellStyler(),
            cellFormatter = columnGrouping.getCellRenderer();

        var columns = [{
            id: "_score",
            name: "Threat Level",
            shortName : 'Level',
            field: "_score",
            sortable : true,
            width: 120,
            toolTip : "'Threat Level' highlights the CVSS (Common Vulnerability Scoring System, version 2) base score for each listed vulnerability.",
            styleFn : function(row, cell, value, columnDef, dataContext) {
                return 'nopad ' + scoreStyler(row, cell, value, columnDef, dataContext);
            },
            sortFn : function(dataRow1, dataRow2) {
                var a = dataRow1['_score'],
                    b = dataRow2['_score'];
                if (isNaN(a) === isNaN(b)) {
                    return ((a < b) ? -1 : ((a > b) ? 1 : 0));
                }
                return a.length < b.length ? 1 : -1;
            },
            formatter : function(row, cell, value, columnDef, dataContext) {
                var colorCls;
                if (value >= 8) {
                    colorCls = ' criticalScore';
                } else if (value >= 4) {
                    colorCls = ' severeScore';
                } else {
                    colorCls = ' moderateScore';
                }
                return '<div class="' + colorCls + '">' + (cellFormatter(row, cell, value, columnDef, dataContext) || "&nbsp;") + '</div>';
            }
        },{
            id: "problemCode",
            name: "Problem Code",
            shortName : 'Code',
            field: "_reference",
            sortable : true,
            width: 105,
            formatter : function(row, cell, value, columnDef, dataContext) {
                var reference = dataContext['_reference'],
					url = dataContext["url"];
                if (isNullOrUndefined(reference)) {
                    return '';
                }
                return '<a href="' + url + '" target="_blank">' + reference + '</a>';
            }
        },{
            id: "groupId",
            name: "Group",
            field: "groupId",
            sortable : true,
            width: 255
        },{
            id: "artifactId",
            name: "Artifact",
            field: "artifactId",
            sortable : true,
            width: 250
        },{
            id: "version",
            name: "Version",
            field: "version",
            sortable : true,
            width: 200,
            sortFn : function(a,b){ return versionComparison.compare(a['version'], b['version']); }
        },{
			id : 'status',
			name : 'Status',
			field : 'status',
            sortable : true,
			width : 200
        }];

        var plugins = [columnGrouping];

        if (isInfoPanelShown()) {
			plugins.push(new Insight.InformationPanel({ sampleData: freemium }));
        }

        securityTable = createTable('security', 'security.json', {
            columns : columns,
            config : config,
            defaultSort : { columnId : '_score', sortAsc : false },
            dataProcessor : function(data){
                var source, reference;
                for (var i=0; i<data.length; i++) {
                    data[i]['id'] = i;
                    data[i]['_score'] = isNullOrUndefined(data[i]['score']) ? "Unscored" : ''+Math.floor(data[i]['score']);

                    source = data[i]['source'];
                    reference = data[i]['reference'];
                    data[i]['_reference'] = (isNullOrUndefined(source) || reference.toUpperCase().indexOf(source.toUpperCase()) === 0) ? reference : source + "-" + reference;

                    data[i].status = isNullOrUndefined(data[i].status) ? 'Open' : data[i].status;
                }
                return data;
            },
            plugins : plugins
        });

        if (freemium) {
            message(securityTable, 'security', 'The data shown below is sample data. To see the security vulnerabilities for <b>your</b> application, <a href="#" data-action="buypro">purchase a subscription.</a>');
        }

        return securityTable;
    }

    function createComponentTable() {
		var matchStates = ['unknown', 'similar', 'exact'],
			vis = "<span class='vervis vervis1'>&nbsp;</span><span class='vervis vervis2'>&nbsp;</span><span class='vervis vervis3'>&nbsp;</span><span class='vervis vervis4'>&nbsp;</span><span class='vervis vervis5'>&nbsp;</span>",
			columns = [{
				id : 'coordinates',
				name : 'Coordinates',
				field : 'coordinates',
				sortable : true,
				width : 275,
				toolTipGravity : 'se',
				toolTipFn : function(row) {
					if (row.modified) {
						return "This record has been manually edited, see the audit log for details";
					}
				},
				formatter : function(row, cell, value, columnDef, dataContext) {
					var result = '';
					if (dataContext.modified) {
						result = '<img src="dirty.gif" style="float:left;margin-top:-2px;margin-left:-6px;"/>';
					} else {
						result = '<div style="width:4px;height:1px;float:left;"></div>';
					}
					if (isNotNullOrUndefined(dataContext.groupId)) {
						result += '<img src="public/coord-gav.png" alt="GAV"/> ';
						result += dataContext.groupId + ' <b>:</b> ' + dataContext.artifactId + ' <b>:</b> ' + dataContext.version;
					} else {
						result += '<img src="public/coord-file.png" alt="File"/> ';
						result += dataContext.filenames.join(', ');
					}
					return result;
				}
			}, {
				id : 'versions',
				name : 'Relative Popularity',
				field : 'relativePopularity',
				sortable : true,
				filterable : false,
				header : '<div class="vervisheader">Least</div><div class="vervisheader" style="text-align:right">Most</div>',
				width : 275,
				sortFn : function(dataRow1, dataRow2) {
					if (dataRow1.matchState === matchStates[0]) {
						return dataRow2.matchState === matchStates[0] ? 0 : -1;
					} else if (dataRow2.matchState === matchStates[0]) {
						return 1;
					}
					return ((dataRow1.relativePopularity < dataRow2.relativePopularity) ? -1 : ((dataRow1.relativePopularity > dataRow2.relativePopularity) ? 1 : 0));
				},
				formatter : function(row, cell, value, columnDef, dataContext) {
					if (dataContext.matchState === matchStates[0]) {
						return "";
					}
					var marker;
					value = Math.round(value * 100);
					if (value < 50) {
						marker = "<span class='verlabel vervisleft' style='left:" + value + "%'>" + dataContext.version + "</span>";
					} else {
						marker = "<span class='verlabel vervisright' style='right:" + (100 - value) + "%'>" + dataContext.version + "</span>";
					}
					return "<div class='verviscontainer'>" + vis + marker + "</div>";
				}
			}, {
				id : 'matchState',
				name : 'Match State',
				field : 'state',
				sortable : true,
				width : 150,
				sortFn : function(dataRow1,dataRow2) {
					var a = matchStates.indexOf(dataRow1.matchState),
						b = matchStates.indexOf(dataRow2.matchState);
					if (a < b) {
						return -1;
					} else if (a > b) {
						return 1;
					} else if (dataRow1.scanError !== dataRow2.scanError) {
						return ((dataRow1.scanError > dataRow2.scanError) ? -1 : 1);
					} else {
						return ((dataRow1.proprietary > dataRow2.proprietary) ? -1 : ((dataRow1.proprietary < dataRow2.proprietary) ? 1 : 0));
					}
				}
			}],
			plugins = [];

        if (isInfoPanelShown()) {
			plugins.push(new Insight.InformationPanel({partialDisplay: freemium, byHash:true}));
        }

        componentTable = createTable('component', 'bom.json', {
            columns : columns,
            multiColumnSort : true,
            selectable : isInfoPanelShown(),
            plugins : plugins,
            defaultSort : [{ columnId : 'matchState', sortAsc : false },{ columnId : 'coordinates', sortAsc : true }],
            dataProcessor : function(data){
                if ( !data ) {
                    data = [];
                }
                for ( var i = 0; i < data.length; i++) {
                    data[i]['id'] = i;
                    if (isNotNullOrUndefined(data[i].groupId)) {
						data[i].coordinates = data[i].groupId + ':' + data[i].artifactId + ':' + data[i].version;
                    } else {
						data[i].coordinates = data[i].filenames.join(', ');
                    }

					if (data[i].matchState === 'unknown') {
						if (data[i].scanError) {
							data[i].state = 'error';
						} else if (data[i].proprietary) {
							data[i].state = 'proprietary';
						} else {
							data[i].state = data[i].matchState;
						}
					} else {
						data[i].state = data[i].matchState;
						if (data[i].proprietary) {
							data[i].state += ' (proprietary)';
						}
					}
                }
                return data;
            }
        });

        $('#componentcontainer ul.nav a').click(function(e){
			e.preventDefault();
			$(this).parents('ul').children('li').removeClass('active');
			$(this).parents('li').addClass('active');

			var text = $(this).text();
			if (text === 'All') {
				$('.slick-headerrow-column input').last().val('').trigger('change');
			} else {
				$('.slick-headerrow-column input').last().val(text).trigger('change');
			}

			componentTable.getData().refresh();
        });
        // fire current state
        $('#componentcontainer ul.nav li.active a').trigger('click');
        return componentTable;
    }

    function createSimilarityTable(data) {
        var columns = [];

        if (!freemium) {
            columns.push({
                id : "_formattedEffectiveLicenseThreat",
                name : "License Threat",
                field : "_formattedEffectiveLicenseThreat",
                sortable : true,
                width : 65,
                sortFn : effectiveLicenseSortFn,
                formatter : effectiveLicenseHtmlFormatFn
            }, {
                id : "securityCounters",
                name : "Security",
                field : "securityCounters",
                sortable : true,
                width : 50,
                sortFn : function(dataRow1,dataRow2) {
                    var result = numberCompare(dataRow1['securityCounters']["Critical"],dataRow2['securityCounters']["Critical"] );
                    if (result === 0) {
                        result = numberCompare(dataRow1['securityCounters']["Severe"],dataRow2['securityCounters']["Severe"] );
                    }
                    if (result === 0) {
                        result = numberCompare(dataRow1['securityCounters']["Moderate"],dataRow2['securityCounters']["Moderate"] );
                    }
                    return result;
                },
                formatter : function(row, cell, value, columnDef, dataContext) {
                    var security = dataContext.securityCounters;
                    var result = '';
                    var total;
                    var offset;
                    if (security) {
                        total = security["Critical"] + security["Severe"] + security["Moderate"];
                        var arrowWidth = 10, width = columnDef.width - arrowWidth;
                        for ( offset = 0; offset > -arrowWidth + 1 && (total - 1) * (arrowWidth + offset) + arrowWidth > width; offset-- ) {}
                        var offsetCounter = 0, maxArrows = (width - arrowWidth) / (arrowWidth + offset) + 1;
                        function getSecurityCounterSpan(count, color) {
                            for ( var i = 0; i < count; i++) {
                                if (offsetCounter >= maxArrows) {
                                    break;
                                }
                                result += '<span class="arrow ' + color + '_arrow" style="left:' + (offsetCounter++ * offset) + 'px"></span>';
                            }
                        }
                        if (security["Critical"]) {
                            getSecurityCounterSpan(security["Critical"], 'red');
                        }
                        if (security["Severe"]) {
                            getSecurityCounterSpan(security["Severe"], 'orange');
                        }
                        if (security["Moderate"]) {
                            getSecurityCounterSpan(security["Moderate"], 'yellow');
                        }
                    }
                    return '<div style="white-space:nowrap;width:' + (offsetCounter > 0 ? 10 + (offsetCounter - 1) * (10 + offset) : 0) + 'px">' + result + "</div>";
                }
            });
        }
        columns.push({
            id : "groupId",
            name : "Group",
            field : "groupId",
            sortable : true,
            width : 90
        }, {
            id : "artifactId",
            name : "Artifact",
            field : "artifactId",
            sortable : true,
            width : 90
        }, {
            id : "version",
            name : "Version",
            field : "version",
            sortable : true,
            width : 30
        });
        similarityTable = createTable('similarity', data, {
            selectable : true,
            disablePager : true,
            disableFilter : true,
            height : 250,
            columns : columns,
            dataProcessor : function(data) {
                if ( !data ) {
                    data = [];
                }

                for ( var i = 0; i < data.length; i++) {
                    data[i]['id'] = i;
                    if (!freemium) {
                        data[i]['_formattedEffectiveLicenseThreat'] = effectiveLicenseFormatFn(data[i].overriddenLicenses, data[i].declaredLicenses, data[i].observedLicenses);
                    }
                }

                return data;
            }
        });
        similarityTable.render(); // No default sort set so this is apparently required
        similarityTable.columnsResizedFn = function() {
            for ( var i = 0 ; i < similarityTable.getDataLength() ; i++ ) {
                similarityTable.updateCell(i,similarityTable.getColumnIndex('securityCounters'));
            }
        };

        similarityTable.onColumnsResized.subscribe(similarityTable.columnsResizedFn);

        $("#informationPanelPartialMatch").click(function(e) {e.stopPropagation();});
    }

    function createAuditTable(data) {
        var columns = [{
            id : "date",
            name : "Date",
            field : "date",
            formatter : function(row, cell, val, columnDef, dataContext) {
                return dateFormat(val, "mmm d yyyy, h:MM:ss tt");
            },
            sortable : true,
            width : 30
        }, {
            id : "user",
            name : "User",
            field : "user",
            toolTipGravity : 'n',
            toolTipFn : function(row) {
                return $('<div/>').text("Edited report in build '" + row.where + "' from " + row.ip).html();
            },
            sortable : true,
            width : 20
        }, {
            id : "action",
            name : "Action",
            field : "action",
            sortable : true,
            width : 20
        }, {
            id : "detail",
            name : "Detail",
            field : "detail",
            sortable : true,
            width : 40
        }, {
            id : "comment",
            name : "Comment",
            field : "comment",
            toolTipGravity : 'n',
            toolTipFn : function(row) {
                return $('<div/>').text(row.comment).html();
            },
            sortable : true,
            width : 80
        }];
        auditTable = createTable('audit', data, {
            resizeFn : $.noop,
            selectable : true,
            disablePager : true,
            disableFilter : true,
            height : 250,
            columns : columns,
            defaultSort : { columnId : 'date', sortAsc : false },
            dataProcessor : function(data) {
                for (var i=0; i<data.length; i++) {
                    data[i]['id'] = i;
                    data[i]['date'] = new Date(data[i]['time']);
                    var action = data[i]['status'];
                    switch (data[i]['status']) {
                        case "Open":
                            action = "Reopened";
                            break;
                        case "Not Applicable":
                            action = "Ignored";
                            break;
                        case "Overridden":
                            action = "Overrode";
                            break;
                    }
                    data[i]['action'] = action;
                    var detail = "";
                    switch (data[i]['filename']) {
                        case "licenses.json":
                            detail = "License ";
                            var overriddenLicenses = data[i]['overriddenLicenses'];
                            if (isNotNullOrUndefined(overriddenLicenses)) {
                                detail += "as " + renderLicenses(overriddenLicenses);
                            } else {
                                detail += "Analysis";
                            }
                            break;
                        case "security.json":
                            detail = "Vulnerability ";
                            var source = data[i]['source'];
                            var reference = data[i]['reference'];
                            if (isNotNullOrUndefined(source) && reference.toUpperCase().indexOf(source.toUpperCase()) !== 0) {
                                detail += source + "-";
                            }
                            detail += reference;
                            break;
                    }
                    data[i]['detail'] = detail;
                }
                return data;
            }
        });

        $("#informationPanelAudit").click(function(e) {e.stopPropagation();});
    }

    // register namespace
	$.extend(true, window, {
		"InsightDatatable" : {
			"createAuditTable" : createAuditTable,
			"createComponentTable" : createComponentTable,
			"createLicenseTable" : createLicenseTable,
			"createSecurityTable" : createSecurityTable,
			"createSimilarityTable" : createSimilarityTable,
			"createTable" : createTable,
			"getEffectiveLicenseOrder" : getEffectiveLicenseOrder,
			"getLicenseThreatImg" : getLicenseThreatImg,
			"isReadOnly" : isReadOnly,
			"removeAuditTable" : removeAuditTable,
			"removeComponentTable" : removeComponentTable,
			"removeLicenseTable" : removeLicenseTable,
			"removeSecurityTable" : removeSecurityTable,
			"removeSimilarityTable" : removeSimilarityTable,
			"updateTableHeight" : updateTableHeight,
			"util" : {
				"getQueryParameter" : getQueryParameter
			}
		}
	});
})();
