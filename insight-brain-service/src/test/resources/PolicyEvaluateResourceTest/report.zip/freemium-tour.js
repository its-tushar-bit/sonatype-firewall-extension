/**
 * Copyright (c) 2012 Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/rhc/pro/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
(function() {
	var counter = 0,
		stopRequested = false;

	function isReadOnly() {
		return $('.slick-header-column:contains("Edit")').length === 0;
	}

	function createStep(node, title, text, buttonText) {
		node = $(node[0]);
		var dataId = node.attr('id');

		if (dataId == null) {
			dataId = "tour" + (counter++);
			node.attr('id', dataId);
		}
		node = $('<li data-id="' + dataId + '" data-text="' + (buttonText || 'Next') + '"><h4></h4><p></p></li>');
		$('h4', node).text(title);
		$('p', node).html(text);
		return node;
	}

	function createTour(id) {
		var node = $('#' + id);

		if (node.length > 0) {
			node.empty();
			return node;
		}
		return $('<ol id="'+id+'" class="hide"></ul>');
	}

	function stopTours() {
		stopRequested = true;
		$('.joyride-close-tip').trigger('click');
		stopRequested = false;
		$('.joyride-tip-guide').remove();
	}

	function triggerRide(id, delay, callback) {
		if (!stopRequested) {
			// Tour is started asynchronously to avoid the new tour from receiving events from a closing tour
			$('.joyride-tip-guide').remove();
			setTimeout(function(){
				$(window).joyride({
					'tipContent' : id,
					'postRideCallback' : function(count, cancelled) {
						if (!cancelled) {
							callback();
						}
					}
				});
			}, delay);
		}
	}

	function getCell(cell, row) {
		if (!isReadOnly()) {
			cell += 1;
		}
		row = row === null ? 0 : row;
		return $('.slick-row[row='+row+'] > .slick-cell.l' + cell);
	}

	function getColumn(text) {
		return $('.slick-column-name:contains(\'' + text + '\')').parent();
	}

	function getFilter(text) {
		return $('.slick-headerrow-columns input[placeholder*=\'' + text + '\']');
	}

	function getTitle(text) {
		return $('.page-header:contains(\'' + text + '\')');
	}

	function startSummaryTour(callback) {
		var tour = createTour('freemium-summary-tour'),
			tour2 = createTour('freemium-summary-tour2');
		$(document.body).append(tour, tour2);

		callback = callback || $.noop;

		createStep($('#summaryBtn'), 'Summary', 'Get an overview of the components that have been analyzed in your application and the number of security and license alerts detected.').appendTo(tour);

		triggerRide('#' + tour.attr('id'), 1, function() {
			createStep(getTitle('Security Issues'), 'Security Issues', 'Quickly see the breakdown of vulnerabilities based on severity and the threat level it poses to your application.').appendTo(tour2);
			createStep($('div.punchcard'), 'Dependency Depth', 'Quickly discover how deep within the dependency tree your issues are located.').appendTo(tour2);
			createStep(getTitle('License Analysis'), 'License Analysis', 'See the number of licenses detected in each category.').appendTo(tour2);

			triggerRide('#' + tour2.attr('id'), 1, callback);
		});
	}

	function startLicenseTour(callback) {
		var tour = createTour('freemium-license-tour'),
			tour2 = createTour('freemium-license-tour2');
		$(document.body).append(tour, tour2);

		callback = callback || $.noop;

		createStep($('#licensecontainerBtn'), 'License Analysis', 'Review and investigate license information for every component in your application. The data shown below is sample data. To see the license data for <b>your</b> application, <a href="#" data-action="buypro">subscribe to detailed reports</a>.').appendTo(tour);

		triggerRide('#' + tour.attr('id'), 1, function() {
			createStep(getColumn('License Threat'), 'License Threat', 'Licenses are sorted by threat level with the riskiest at the top. License are categorized as Copyleft (red), Non-standard or Not Provided (orange), Weak Copyleft (yellow) and Liberal (blue).').appendTo(tour2);
			createStep(getCell(0, 1), 'Declared License', 'If a component has a declared license, it\'s bolded in the \'License Threat\' list. All other licenses were discovered by Sonatype\'s analysis of the component source and binaries.').appendTo(tour2);
			createStep(getColumn('Group'), 'Sortable Columns', 'Sort and filter any column to find the information you need quickly.').appendTo(tour2);
			createStep(getColumn('Status'), 'Status', 'This column shows the current status of the license analysis, which can be Open, Acknowledged, Overridden, or Confirmed.').appendTo(tour2);

			var editBtn = getColumn('Edit');
			if (editBtn.length !== 0) {
				createStep(editBtn, 'Bulk Edit', 'Check multiple boxes and then click here to edit the License Status of multiple components all at once.').appendTo(tour2);
			}

			triggerRide('#' + tour2.attr('id'), 1, function() {
				createArtifactInfoPanelTour(callback, createArtifactLicenseTour);
			});
		});
	}

	function startSVTour(callback) {
		var tour = createTour('freemium-sv-tour'),
			tour2 = createTour('freemium-sv-tour2');
		$(document.body).append(tour, tour2);
		callback = callback || $.noop;

		createStep($('#securitycontainerBtn'), 'Security Issues', 'Review and investigate any security vulnerabilities found in the components in your application. The data shown below is sample data. To see the security vulnerabilities for <b>your</b> application, <a href="#" data-action="buypro">subscribe to detailed reports</a>.', 'Next').appendTo(tour);

		triggerRide('#' + tour.attr('id'), 1, function() {
			createStep(getCell(0, 0), 'Threat Level', 'Vulnerabilities are sorted by threat level. Threat levels are derived from the <a target="_blank" href="http://www.first.org/cvss/cvss-guide.html">CVSS base score</a>.').appendTo(tour2);
			createStep(getCell(1, 0), 'Problem Code', 'Go directly to the source to drill down on the details for any vulnerability.').appendTo(tour2);
			createStep(getColumn('Group'), 'Sortable Columns', 'Sort and filter any column to find the information you need quickly.').appendTo(tour2);
			createStep(getColumn('Status'), 'Status', 'This column shows the current status of the vulnerability, which can be Open, Acknowledged, Not Applicable, or Confirmed.').appendTo(tour2);

			var editBtn = getColumn('Edit');
			if (editBtn.length !== 0) {
				createStep(editBtn, 'Bulk Edit', 'Check multiple boxes and then click here to edit the Vulnerability Status of multiple issues all at once.').appendTo(tour2);
			}

			triggerRide('#' + tour2.attr('id'), 1, function() {
				createArtifactInfoPanelTour(callback, createArtifactSVTour);
			});
		});
	}

	function startComponentTour(callback) {
		var tour = createTour('freemium-component-tour'),
			tour2 = createTour('freemium-component-tour2');
		$(document.body).append(tour, tour2);

		callback = callback || $.noop;

		createStep($('#componentcontainerBtn'), 'Components', 'Get a complete list of the components found in your application.').appendTo(tour);

		triggerRide('#' + tour.attr('id'), 1, function() {
			createStep(getColumn('Coordinates'), 'Coordinates', 'The identity of your component is listed here. If the component is known, then we will display the Maven coordinate. If it is unknown or proprietary, then we will display the path and filename of the component as it exists in your application.').appendTo(tour2);
			createStep(getColumn('Match State'), 'Match State', 'This column displays how closely the component in your application matched the known open source component.').appendTo(tour2);
			createStep(getColumn('Coordinates'), 'Sortable Columns', 'Sort and filter any column to find the information you need quickly.').appendTo(tour2);

			triggerRide('#' + tour2.attr('id'), 1, function() {
				createComponentInfoPanelTour(callback);
			});
		});
	}

	function createArtifactInfoPanelTour(callback, createDetailedTour) {
		var tour = createTour('freemium-aip-tour');
		$(document.body).append(tour);

		callback = callback || $.noop;

		// open panel
		$(getCell(0, 0)).trigger('click');

		// make sure we're on right tab
		var btn = $('#informationPanel a:contains(\'Component Info\')');
		btn.trigger('click');

		if (isReadOnly()) {
			triggerRide('#' + tour.attr('id'), 1, callback); // short-circuit the CIP tour, since this is either an old (uneditable) report or an old plugin 
			return;
		}

		createStep(getCell(0, 1), 'Component Information Panel', 'Get complete details for every component in the Component Information Panel.').appendTo(tour);

		triggerRide('#' + tour.attr('id'), 1, function() {
			createArtifactInfoPanelTour2(callback, createDetailedTour);
		});
	}

	function createArtifactInfoPanelTour2(callback, createDetailedTour) {
		var tour = createTour('freemium-aip-tour2');
		$(document.body).append(tour);

		callback = callback || $.noop;

		createStep($('#infoPanelArtifactTable'), 'Component Metadata', 'Basic information for each component is found on the left.').appendTo(tour);
		createStep($('#aiVersionChartContainer'), 'Component Version Awareness', 'The graphs on the right show popularity, license and security details for all versions of a component. The version you\'re currently using is centered in the graph.').appendTo(tour);

		triggerRide('#' + tour.attr('id'), 1, (createDetailedTour) ? function() {createDetailedTour(callback);} : callback);
	}

	function createArtifactLicenseTour(callback) {
		var tour = createTour('freemium-aip-license-tour');
		$(document.body).append(tour);

		callback = callback || $.noop;

		// make sure we're on right tab
		var btn = $('#informationPanel a:contains(\'Edit License\')');
		btn.trigger('click');

		createStep(btn, 'Edit License', 'Here you can edit the status of a license investigation, and if needed, override the license.').appendTo(tour);

		triggerRide('#' + tour.attr('id'), 1, function() {
			createArtifactLicenseTour2(callback);
		});
	}

	function createArtifactLicenseTour2(callback) {
		var tour = createTour('freemium-aip-license-tour2');
		$(document.body).append(tour);

		callback = callback || $.noop;

		createStep($('#informationPanelEditLicense .divider'), 'Declared Licenses', 'This is the license declared by the component\'s project, usually in the Maven POM.').appendTo(tour);
		createStep($('#informationPanelEditLicense .nav-list:last'), 'Observed Licenses', 'These are the licenses Sonatype has detected in a scan of the component sources and/or binaries.').appendTo(tour);
		createStep($('#informationPanelEditLicense .control-label:first'), 'License Status', 'The license status is used to indicate where you are in your investigation of the licenses. Acknowledge an issue to temporarily stop build alerts from being produced while it is being investigated. If you would like to override the license (for example to pick one of multiple license options), select Override and then pick the license to use. If the license matches your expectations, then mark it as Confirmed.').appendTo(tour);

		triggerRide('#' + tour.attr('id'), 1, callback);
	}

	function createArtifactSVTour(callback) {
		var tour = createTour('freemium-aip-sv-tour');
		$(document.body).append(tour);

		callback = callback || $.noop;

		// make sure we're on right tab
		var btn = $('#informationPanel a:contains(\'Edit Vulnerabilities\')');
		btn.trigger('click');

		createStep(btn, 'Edit Vulnerabilities', 'Here you can quickly see all vulnerabilities for this component and update their status.').appendTo(tour);

		triggerRide('#' + tour.attr('id'), 1, function() {
			createArtifactSVTour2(callback);
		});
	}

	function createArtifactSVTour2(callback) {
		var tour = createTour('freemium-aip-sv-tour2');
		$(document.body).append(tour);

		callback = callback || $.noop;

		createStep($('#informationPanelEditSV .slick-viewport:last'), 'Component Vulnerabilities', 'All known vulnerabilities for this component are shown here.').appendTo(tour);
		createStep($('#informationPanelEditSV .slick-header:first'), 'Selection', 'Select one or more vulnerabilities to edit their status all at once.').appendTo(tour);
		createStep($('#informationPanelEditSV .control-label:first'), 'Issue Status', 'The status of a vulnerability is used to indicate where you are in your investigation. Acknowledge an issue to temporarily stop build alerts from being produced while it is being investigated. If the issue doesn\'t apply to your application, mark it as Not Applicable. If it does apply, then flag it as Confirmed and then visit the Component Info tab to find a better version.').appendTo(tour);

		triggerRide('#' + tour.attr('id'), 1, callback);
	}

	function createComponentInfoPanelTour(callback) {
		var tour = createTour('freemium-cip-tour');
		$(document.body).append(tour);

		callback = callback || $.noop;

		// select specific slf4j artifact from sample report
		getFilter('Search Coordinates').val('slf4j').change();

		// open panel
		$(getCell(0, 0)).trigger('click');

		// make sure we're on right tab
		var btn = $('#informationPanel a:contains(\'Component Info\')');
		btn.trigger('click');

		createStep(getCell(0, 1), 'Component Information Panel', 'Get complete details for every component in the Component Information Panel.').appendTo(tour);

		triggerRide('#' + tour.attr('id'), 1, function() {
			createSimilarComponentsTour(callback);
		});
	}

	function createSimilarComponentsTour(callback) {
		var tour = createTour('freemium-cip-similar-tour');
		$(document.body).append(tour);

		callback = callback || $.noop;

		// make sure we're on right tab
		var btn = $('#informationPanel a:contains(\'Similar Components\')');
		btn.trigger('click');

		createStep(btn, 'Similar Components', 'This view will show you other components that had a close match to yours.').appendTo(tour);

		triggerRide('#' + tour.attr('id'), 1, callback);
	}

	$.extend(true, window, {
		"Insight" : {
			"startSummaryTour" : startSummaryTour,
			"startComponentTour" : startComponentTour,
			"startLicenseTour" : startLicenseTour,
			"startSVTour" : startSVTour,
			"stopTours" : stopTours
		}
	});
})();
